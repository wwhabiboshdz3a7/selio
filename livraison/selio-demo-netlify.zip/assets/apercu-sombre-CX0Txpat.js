const s="/assets/apercu-clair-CsJ63asV.webp",a="/assets/apercu-sombre-4h3ex02s.webp";export{s as a,a as b};
