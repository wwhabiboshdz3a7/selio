import{A as s,M as L}from"./geometry-Cp0RNCW7.js";const e=s,A=L.map(t=>({id:t.id,title:t.title,text:t.summary,href:t.href,tone:t.tone,status:t.status}));export{A as C,e as S};
